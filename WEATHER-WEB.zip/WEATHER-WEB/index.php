<?php
session_start();

// Cek apakah pengguna telah login
if (!isset($_SESSION['loggedIn']) || $_SESSION['loggedIn'] !== true) {
    // Pengguna belum login, alihkan ke halaman login
    header('Location: login.php');
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>WEATHER</title>
  <script type="text/javascript" src="./js/main.js" defer></script>
  <script type="text/javascript" src="./js/script.js" defer></script>
  <link rel="stylesheet" href="./css/main.css">
  <style>
    body {
      background-image: url('./img/cloudy.jpg');
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
    }
  </style>
</head>
<body onload="loadSite()">
  <div class="container">
    <!-- Navigation Bar -->
    <div class="container-navbar">
        <ul class="ul-navbar">
            <li class="li-navbar">
                <a href="#" class="a-navbar">HOME</a>
            </li>
            <li class="li-navbar">
                <a href="aboutus.php" class="a-navbar">ABOUT US</a>
            </li>
            <li class="li-navbar">
                <a href="contactus.php" class="a-navbar">CONTACT US</a>
            </li>
            <li class="li-navbar">
                <a href="logout.php" class="a-navbar">LOG OUT</a>
            </li>
        </ul>
    </div>

    <div class="container">
      <p>Weather</p>
      <form id="search-form" onsubmit="searchWeather(); return false;">
      <input type="text" name="city" placeholder="Masukkan nama kota">
  <button onclick="searchWeather()">Search</button>
</form>
<div id="weather-results"></div>
      <h1 id="temperature"></h1>
      <p id="description"></p>
      <h2 id="location"></h2>
      <!-- tables -->
      <div class="table-container">
        <table class="table">
          <thead>
            <tr>
              <th>City</th>
              <th>Temperature</th>
              <th>Humidity</th>
              <th>Pressure</th>
              <th>Wind Speed</th>
              <th>Wind Direction</th>
              <th>Sunrise</th>
              <th>Sunset</th>
            </tr>
          </thead>
          <tbody id="table-body">
            <tr>
              <td id="data_city">Manado</td>
              <td id="data_temperature">25.4</td>
              <td id="data_humidity">94</td>
              <td id="data_pressure">1011</td>
              <td id="data_wind_speed">1.03</td>
              <td id="data_wind_direction">0</td>
              <td id="data_sunrise">05:34:26</td>
              <td id="data_sunset">05:46:44</td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</body>
</html>