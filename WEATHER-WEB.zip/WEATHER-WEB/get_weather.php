<?php
// Koneksi ke database
$servername = "sql303.infinityfree.com";
$username = "if0_34415919";
$password = "yygtCS02t6";
$dbname = "if0_34415919_weather_db";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Koneksi ke database gagal: " . $conn->connect_error);
}

// Ambil nilai kota dari permintaan AJAX
$city = $_POST['city'];

// Ambil data cuaca dari database berdasarkan kota
$sql = "SELECT * FROM weather_data WHERE city = '$city'";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Ambil baris pertama hasil query
    $row = $result->fetch_assoc();

    // Simpan data cuaca ke dalam array
    $weatherData = [
        'city' => $row['city'],
        'description'=> $row['description'],
        'temperature' => $row['temperature'],
        'humidity' => $row['humidity'],
        'pressure' => $row['pressure'],
        'wind_speed' => $row['wind_speed'],
        'wind_direction' => $row['wind_direction'],
        'sunrise' => $row['sunrise'],
        'sunset' => $row['sunset']
    ];

    // Mengembalikan data cuaca dalam format JSON
    echo json_encode($weatherData);
} else {
    // Jika data cuaca tidak ditemukan, kirimkan response kosong
    echo json_encode([]);
}

$conn->close();
?>
