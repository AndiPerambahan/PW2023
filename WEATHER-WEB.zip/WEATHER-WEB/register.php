<?php
session_start();

// Cek apakah pengguna sudah login, jika ya, arahkan ke halaman utama
if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
    header('Location: index.php');
    exit;
}

// Proses form pendaftaran
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $username = $_POST['username'];
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirm_password'];

    // Hubungkan ke server MySQL menggunakan fungsi mysqli_connect()
    $koneksi = mysqli_connect('sql303.infinityfree.com', 'if0_34415919', 'yygtCS02t6', 'if0_34415919_weather_db');

    // Periksa koneksi ke database
    if (mysqli_connect_errno()) {
        echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
        exit;
    }

    // Lakukan sanitasi input pengguna
    $username = mysqli_real_escape_string($koneksi, $username);
    $password = mysqli_real_escape_string($koneksi, $password);

    // Periksa apakah password dan konfirmasi password cocok
    if ($password !== $confirmPassword) {
        echo "Password dan konfirmasi password tidak cocok.";
        exit;
    }

    // Hash password menggunakan password_hash()
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Buat query untuk menyimpan data akun ke tabel yang sesuai
    $query = "INSERT INTO user (username, password) VALUES ('$username', '$hashedPassword')";

    // Jalankan query
    $result = mysqli_query($koneksi, $query);

    // Periksa apakah query berhasil dieksekusi
    if ($result) {
        echo "Pendaftaran berhasil. Anda dapat masuk sekarang.";
    } else {
        echo "Terjadi kesalahan: " . mysqli_error($koneksi);
    }

    // Tutup koneksi ke database
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Daftar Akun</title>
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <h2>Daftar Akun</h2>
    <form method="POST" action="">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <label for="confirm_password">Konfirmasi Password:</label><br>
        <input type="password" id="confirm_password" name="confirm_password" required><br><br>

        <input type="submit" value="Daftar">
    </form>
    <br><a href="login.php">Masuk</a>
</body>
</html>
