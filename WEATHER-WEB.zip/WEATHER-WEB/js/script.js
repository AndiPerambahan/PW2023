function searchWeather() {
    // Ambil nilai input kota
    let city = document.querySelector('input[name="city"]').value;

    // Buat permintaan AJAX ke server
    fetch('get_weather.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'city=' + encodeURIComponent(city)
    })
    .then(function(response) {
        return response.json();
    })
    .then(function(json) {
        // Tampilkan data cuaca pada halaman web
        document.getElementById("temperature").innerHTML = json.temperature + "°C";
        document.getElementById("location").innerHTML = json.city;
        document.getElementById("description").innerHTML = json.description;
        document.getElementById("data_city").innerHTML = json.city;
        document.getElementById("data_temperature").innerHTML = json.temperature + "°C";
        document.getElementById("data_humidity").innerHTML = json.humidity + "%";
        document.getElementById("data_wind_speed").innerHTML = json.wind_speed + "m/s";
        document.getElementById("data_wind_direction").innerHTML = json.wind_direction + "º";
        document.getElementById("data_pressure").innerHTML = json.pressure + "hPa";
        document.getElementById("data_sunrise").innerHTML = json.sunrise + " AM";
        document.getElementById("data_sunset").innerHTML = json.sunset + " PM";
    });
}
