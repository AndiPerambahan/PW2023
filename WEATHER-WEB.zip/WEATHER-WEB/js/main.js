let longitude = "1.360321";
let latitude = "103.846733";

function loadSite (def3ac78f5d4e1775d3dab8c35b4757b) {
  if (navigator.geolocation) { // device can return its location
    navigator.geolocation.getCurrentPosition(function(position) {
      latitude = position.coords.latitude;
      longitude = position.coords.longitude;
      getWeather();
    });
  }
}
function getWeather () {
    let url = `http://api.openweathermap.org/data/2.5/weather?lat=${1.481}&lon=${124.8518}&appid=def3ac78f5d4e1775d3dab8c35b4757b`
    console.log(url);
    fetch(url)
    .then(function(response) {
      return response.json();
    })
    .then(function(json) {
      console.log(json);
      switch(json.weather[0].main){
        case "Rain":
          document.body.style.backgroundImage = "url('./img/rainy.jpg')";
          break;
        case "Clouds":
          document.body.style.backgroundImage = "url('./img/cloudy.jpg')";
          break;
        case "Clear":
          document.body.style.backgroundImage = "url('./img/clear.jpg')";
          break;
        default:
          document.body.style.backgroundImage = "url('./img/fair.jpg')";
          break;
      }
  
      document.getElementById("temperature").innerHTML = Math.round((json.main.temp-273.15)*10)/10 + "°C";
      document.getElementById("location").innerHTML = json.name;
      document.getElementById("description").innerHTML = json.weather[0].description;
      document.getElementById("data_city").innerHTML = json.name;
      document.getElementById("data_temperature").innerHTML = Math.round((json.main.temp-273.15)*10)/10 + "°C";
      document.getElementById("data_humidity").innerHTML = json.main.humidity + "%";
      document.getElementById("data_wind_speed").innerHTML = json.wind.speed + "m/s";
      document.getElementById("data_wind_direction").innerHTML = json.wind.deg + "º";
      document.getElementById("data_pressure").innerHTML = json.main.pressure + "hPa";
      document.getElementById("data_sunrise").innerHTML = new Date(json.sys.sunrise*1000).toLocaleTimeString();
      document.getElementById("data_sunset").innerHTML = new Date(json.sys.sunset*1000).toLocaleTimeString();
    });
  }