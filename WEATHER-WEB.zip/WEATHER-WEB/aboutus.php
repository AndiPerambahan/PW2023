<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>ABOUT US</title>
  <script type="text/javascript" src="./js/main.js" defer></script>
  <link rel="stylesheet" href="./css/main.css">
   <style>
    body {
      background-image: url('./img/fair.jpg');
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
    }
  </style>
</head>
<body onload="loadSite()">
  <!-- Navigation Bar -->
  <div class="container-navbar">
    <ul class="ul-navbar">
      <li class="li-navbar">
        <a href="index.php" class="a-navbar">HOME</a>
      </li>
      <li class="li-navbar">
        <a href="aboutus.php" class="a-navbar">ABOUT US</a>
      </li>
      <li class="li-navbar">
        <a href="contactus.php" class="a-navbar">CONTACT US</a>
      </li>
      <li class="li-navbar">
        <a href="logout.php" class="a-navbar">LOG OUT</a>
      </li>
    </ul>
  </div>

  <div class="container">
    <h3>Kelompok F2</h3>
    <p>ANGGOTA KELOMPOK</p>
    <div class="table-container">
      <div class="card">
        <img src="./img/arikurniawan.jpeg" alt="Ari" class="member-image">
        <div class="member-info">
          <h3>Ari Kurniawan</h3>
          <p class="nim">210211060271</p>
        </div>
      </div>

      <div class="card">
        <img src="./img/andika.jpeg" alt="Andika" class="member-image">
        <div class="member-info">
          <h3>Andika Pratama</h3>
          <p class="nim">210211060072</p>
        </div>
      </div>

      <div class="card">
        <img src="./img/ikyw.jpeg" alt="Ikyw" class="member-image">
        <div class="member-info">
          <h3>Rizky Walangadi</h3>
          <p class="nim">210211060060</p>
        </div>
      </div>

      <div class="card">
        <img src="./img/andi.jpeg" alt="Andi" class="member-image">
        <div class="member-info">
          <h3>Andi Perambahan</h3>
          <p class="nim">210211060270</p>
        </div>
      </div>
    </div>
  </div>
</body>
</html>
