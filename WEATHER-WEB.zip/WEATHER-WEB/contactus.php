<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>CONTACT US</title>
  <script type="text/javascript" src="./js/main.js" defer></script>
  <link rel="stylesheet" href="./css/main.css">
   <style>
    body {
      background-image: url('./img/rainy.jpg');
      background-repeat: no-repeat;
      background-position: center;
      background-size: cover;
    }
  </style>
     <!-- Navigation Bar -->
     <div class="container-navbar">
        <ul class="ul-navbar">
            <li class="li-navbar">
                <a href="index.php" class="a-navbar">HOME</a>
            </li>
            <li class="li-navbar">
                <a href="aboutus.php" class="a-navbar">ABOUT US</a>
            </li>
            <li class="li-navbar">
                <a href="contactus.php" class="a-navbar">CONTACT US</a>
            </li>
            <li class="li-navbar">
                <a href="logout.php" class="a-navbar">LOG OUT</a>
            </li>
        </ul>
    </div>
</head>
<body onload="loadSite()">
 </body<div class="container">
    <h3>Kelompok F2</h3>
    <p>ANGGOTA KELOMPOK</p>
    <!-- tables -->
    <div class="table-container">
      <table class="table">
        <thead>
          <tr>
            <th>ARI KURNIAWAN</th>
            <th>ANDHIKA RIZKY PRATAMA</th>
            <th>MUHAMAD RIZKY HERLAMBANG</th>
            <th>ANDI PERAMBAHAN</th>
          </tr>
        </thead>
        <tbody id="table-body">
          <tr>
            <td id="INSTAGRAM_ARI KURNIAWA"><a href="https://instagram.com/ark._.27?igshid=YmMyMTA2M2Y=">@ark._.27</a></td>
            <td id="INSTAGRAM_ARI KURNIAWA"><a href="https://instagram.com/ant.ttoo?igshid=YmMyMTA2M2Y==">@ant.ttoo</a></td>
            <td id="INSTAGRAM_ARI KURNIAWA"><a href="https://instagram.com/rzkywlngdi?igshid=YmMyMTA2M2Y=">@rzkywlngdi</a></td>
            <td id="INSTAGRAM_ARI KURNIAWA"><a href="https://instagram.com/andi._.az?igshid=ZDdkNTZiNTM=">@andi._.az</a></td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</html>