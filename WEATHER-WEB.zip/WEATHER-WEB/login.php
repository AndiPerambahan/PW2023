<?php
session_start();

// Cek apakah pengguna sudah login, jika ya, arahkan ke halaman utama
if (isset($_SESSION['loggedIn']) && $_SESSION['loggedIn'] === true) {
    header('Location: index.php');
    exit;
}

// Proses form login
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Hubungkan ke server MySQL menggunakan fungsi mysqli_connect()
    $koneksi = mysqli_connect('sql303.infinityfree.com', 'if0_34415919', 'yygtCS02t6', 'if0_34415919_weather_db');

    // Periksa koneksi ke database
    if (mysqli_connect_errno()) {
        echo "Gagal terhubung ke MySQL: " . mysqli_connect_error();
        exit;
    }

    // Lakukan sanitasi input pengguna
    $username = mysqli_real_escape_string($koneksi, $username);
    $password = mysqli_real_escape_string($koneksi, $password);

    // Buat query untuk memeriksa kredensial pengguna
    $query = "SELECT * FROM user WHERE username = '$username'";
    $result = mysqli_query($koneksi, $query);

    // Periksa apakah query berhasil dieksekusi dan hasilnya mengandung satu baris pengguna
    if (mysqli_num_rows($result) === 1) {
        $row = mysqli_fetch_assoc($result);
        $hashedPassword = $row['password'];

        // Verifikasi password menggunakan password_verify()
        if (password_verify($password, $hashedPassword)) {
            $_SESSION['loggedIn'] = true;
            header('Location: index.php');
            exit;
        }
    }

    // Jika username atau password tidak valid, tampilkan pesan error
    $errorMessage = 'Username atau password tidak valid.';

    // Tutup koneksi ke database
    mysqli_close($koneksi);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Halaman Login</title>
    <link rel="stylesheet" href="./css/main.css">
</head>
<body>
    <h2>Login</h2>
    <?php if (isset($errorMessage)): ?>
        <p style="color: red;"><?php echo $errorMessage; ?></p>
    <?php endif; ?>
    <form method="POST" action="">
        <label for="username">Username:</label><br>
        <input type="text" id="username" name="username" required><br><br>

        <label for="password">Password:</label><br>
        <input type="password" id="password" name="password" required><br><br>

        <input type="submit" value="Login">
    </form>
    <br><a href="register.php">Daftar Akun</a>
</body>
</html>
